exp = input("Expression:")
def maths(x):
    lst = []
    i,j = 0,0
    while j < len(x):
        if x[j] == ' ':
            lst.append(x[i:j])
            i = j+1
        if j == len(x)-1:
            lst.append(x[i:])
        j += 1
    if lst[1] == '+':
        res = int(lst[0]) + int(lst[2])
        return float(res)
    if lst[1] == '-':
        res = int(lst[0]) - int(lst[2])
        return float(res)
    if lst[1] == '*':
        res = int(lst[0]) * int(lst[2])
        return float(res)
    if lst[1] == '/':
        res = int(lst[0]) / int(lst[2])
        return res
print(maths(exp.strip()))
