string = input()
print(string.replace(" ","..."))
