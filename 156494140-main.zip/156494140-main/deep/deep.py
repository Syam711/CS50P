def check(ans):
    if ans == "42":
        return 'Yes'
    if ans == "forty two":
        return "Yes"
    if ans == "forty-two":
        return "Yes"
    else:
        return "No"
string = input("What is the Answer to the Great Question Of Life, the Universe, and Everything?")
ans = string.lower()
print(check(ans.strip()))

