import inflect
p = inflect.engine()
try:
    lst = []
    while True:
        name = input()
        if name == 'EOF':
            break
        else:
            lst.append(name)
except EOFError:
    pass
finally:
    print('Adieu, adieu, to',p.join(lst))
