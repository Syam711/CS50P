#This is a comment

print(2)
