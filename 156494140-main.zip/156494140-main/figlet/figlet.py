import pyfiglet
import sys
import random
font_list = pyfiglet.FigletFont.getFonts()
if len(sys.argv) == 2:
     sys.exit('Invalid Usage')
elif len(sys.argv) == 3:
        if sys.argv[1] == '-f' or sys.argv[1] == '--font' and sys.argv[2] in font_list:
            inp = input('Input: ')
            f = pyfiglet.Figlet(font = sys.argv[2])
            print(f.renderText(inp))
        else:
            sys.exit('Invalid usage')
elif len(sys.argv) == 1:
    inp = input('Input: ')
    f = pyfiglet.Figlet(font = random.choice(font_list))
    print(f.renderText(inp))
else:
     sys.exit('Invalid Usage')

