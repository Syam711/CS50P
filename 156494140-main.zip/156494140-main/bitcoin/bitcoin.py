import sys
import requests

def main():
    if len(sys.argv) != 2:
        sys.exit('Missing command-line argument')
    if sys.argv[1].isalpha():
        sys.exit('Command-line argument is not a number')
    else:
        try:
            num = float(sys.argv[1])
        except ValueError:
            sys.exit('Command-line argument is not a number')
        else:
            try:
                response = requests.get('https://api.coindesk.com/v1/bpi/currentprice.json')
            except requests.RequestException as e:
                sys.exit(e)
            else:
                dct = response.json()
                amount = num * (dct['bpi']['USD']['rate_float'])
                print(f'${amount:,.4f}')

main()
