def main() -> None:
    try :
        dct = {}
        while True:
            item : str = input()
            if item == 'EOF':
                break
            if item not in dct:
                dct[item] = 1
            else:
                dct[item] += 1

    except EOFError:
        print()
        for i in sorted(dct):
            print(dct[i],i.upper())

if __name__ == '__main__':
    main()
