def check(lst):
    date = input('Date:')
    if date[0].isalpha():
        lst1 = [i.split() for i in date.split(',')]
        lst1[0][0] = lst.index(lst1[0][0].title()) + 1
        mm = lst1[0][0]
        dd = lst1[0][1]
        year = lst1[1][0]
    else:
        lst1 = date.split('/')
        mm = lst1[0]
        dd = lst1[1]
        year = lst1[2]
    return int(mm),int(dd),int(year)
def main():
    try:
        lst =  [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"
            ]
        mm,dd,year = check(lst)
    except:
        main()
    else:
        if mm > 12 or mm < 1:
            main()
        if dd > 31 or dd < 1:
            main()
        print(f'{year}-{mm:02}-{dd:02}')
main()

