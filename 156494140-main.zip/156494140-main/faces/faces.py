def main(string):
    lst = string.split()
    for word in range(len(lst)):
        if lst[word] == ":)":
            lst[word] = '🙂'
        if lst[word] == ":(":
            lst[word] = '🙁'
    return ' '.join(lst)
string = input()
print(main(string))
