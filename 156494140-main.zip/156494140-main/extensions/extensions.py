def group(x):
    lst = x.split(".")
    check = lst[-1].lower()
    if check == "jpeg" or check == 'jpg':
        return 'image/jpeg'
    if check == 'gif':
        return 'image/gif'
    if check == 'pdf':
        return 'application/pdf'
    if check == 'txt':
        return 'text/plain'
    if check == 'zip':
        return 'application/zip'
    if check == 'png':
        return 'image/png'
    else:
        return 'application/octet-stream'
file = input("File name:")
print(group(file.strip()))
