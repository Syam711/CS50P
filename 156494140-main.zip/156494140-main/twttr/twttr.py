def main():
    word = input()
    print(shorten(word))

def shorten(word) -> str:
    lst = []
    vowels = {'A','E','I','O','U','a','e','i','o','u'}
    for letter in word:
        if letter in vowels:
            continue
        else:
            lst.append(letter)
    return ''.join(lst)

if __name__ == '__main__':
    main()
