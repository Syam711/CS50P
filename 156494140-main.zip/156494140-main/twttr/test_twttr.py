from twttr import shorten
def test_shortened():
    assert shorten('ABCD') == 'BCD'
    assert shorten('a27ih0o') == '27h0'
    assert shorten('abcd') == 'bcd'
    assert shorten('ABecIk') == 'Bck'
    assert shorten('This_is_Syam') == 'Ths_s_Sym'
    assert shorten('b131,.;d') == 'b131,.;d'
