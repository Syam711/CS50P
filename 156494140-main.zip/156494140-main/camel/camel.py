def main() -> None:
    camelCase: str = input("camelCase: ")
    lst = [i for i in camelCase]
    for let in range(len(lst)):
        if lst[let].isupper():
            lst[let] = lst[let].lower()
            lst.insert(let,'_')
    snake_case = ''.join(lst)
    print(f'snake_case:{snake_case}')
if __name__ == '__main__':
    main()
