def main() -> None:
    flag = 1
    coin_inserted = 0
    amount_due = 50
    while flag ==1 :
        toBePaid = amount_due - coin_inserted
        if toBePaid > 0:
            print(f"Amount Due: {toBePaid}")
            coin_drop = int(input("Insert Coin: "))
            if coin_drop == 5 or coin_drop == 10 or coin_drop == 25:
                coin_inserted += coin_drop
            else:
                continue
        else:
            print("Change Owed:",coin_inserted - amount_due)
            flag = 0
if __name__ == '__main__':
    main()
