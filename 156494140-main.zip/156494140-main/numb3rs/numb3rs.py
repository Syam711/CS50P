import re
import sys


def main():
    print(validate(input("IPv4 Address: ")))


def validate(ip):
    try:
        if len(ip.split('.')) != 4:
            return False
        for i in ip.split('.'):
            if 0<=int(i)<=255:
                continue
            else:
                return False
        return True
    except:
        return False
if __name__ == "__main__":
    main()
