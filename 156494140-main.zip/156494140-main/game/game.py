import random
def level():
    try:
        inp = int(input('Level: '))
    except ValueError:
        level()
    else:
        if inp < 1:
            level()
        return inp
def guess():
    try:
        inp = int(input('Guess: '))
    except ValueError:
        guess()
    else:
        if inp < 1:
            guess()
        return inp
def result(system):
    player_guess = guess()
    if player_guess < system:
        print('Too small!')
        result(system)
    if player_guess > system:
        print('Too large!')
        result(system)
    if player_guess == system:
        print('Just right!')

def main():
    game_level = level()
    system_guess = random.randint(1,game_level+1)
    result(system_guess)

if __name__ == '__main__':
    main()



