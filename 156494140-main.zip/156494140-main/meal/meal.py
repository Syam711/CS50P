def convert(time: str):
    lst = time.split(':')
    return float(lst[0]) + (float(lst[1])/60)
def main()-> None:
    user = input("What time is it?")
    time = user.strip()
    convert(time)
    lst = time.split(':')
    res = (int(lst[0]) * 60) + int(lst[1])
    if res >= 420 and res <= 480:
        print("breakfast time")
    elif res >= 720 and res <= 780:
        print('lunch time')
    elif res >= 1080 and res <= 1140:
        print('dinner time')
if __name__ == '__main__':
    main()

