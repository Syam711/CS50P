import emoji as e
inp = input('Input: ')
print('Output:',e.emojize(inp, language = 'alias'))
