def main() -> None:
    fruit = input("Item:")
    check = fruit.strip()
    if check.lower() == 'apple':
        print("Calories: 130")
    if check.lower() == 'banana':
        print('Calories: 110')
    if check.lower() == 'avocado':
        print('Calories: 50')
    if check.lower() == 'sweet cherries':
        print('Calories: 100')
    if check.lower() == 'kiwifruit':
        print('Calories: 90')
    if check.lower() == 'pear':
        print('Calories: 100')
if __name__ == '__main__':
    main()



