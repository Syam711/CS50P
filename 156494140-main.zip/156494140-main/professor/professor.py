import random

def main():
    lvl = get_level()
    sums = generate_integer(lvl)
    count = 0
    for i in range(10):
        chance = 3
        while chance:
            try:
                print(f'{sums[i][0]} + {sums[i][1]} = ',end ='' )
                inp = int(input())
            except ValueError:
                print('EEE')
                chance -= 1
                continue
            else:
                if inp == sums[i][0] + sums[i][1]:
                    count += 1
                    break
                else:
                    chance -= 1
                    print('EEE')
        if chance == 0:
            print(f'{sums[i][0]} + {sums[i][1]} = {sums[i][0] + sums[i][1]}' )
    print('Score:',count)

def get_level():
    while True:
        try:
            inp = int(input('Level: '))
            if 1 <= inp <= 3:
                return inp
        except:
            pass

def generate_integer(level):
    lst = []
    if level == 1:
        for _ in range(10):
            lst.append((random.randint(0,9),random.randint(0,9)))
        return lst
    if level == 2:
        for _ in range(10):
            lst.append((random.randint(10,99),random.randint(10,99)))
        return lst
    if level == 3:
        for _ in range(10):
            lst.append((random.randint(100,999),random.randint(100,999)))
        return lst
    else:
        raise ValueError


if __name__ == '__main__':
    main()
