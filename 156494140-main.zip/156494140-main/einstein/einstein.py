mass = int(input())
E = mass * ((3*(10**8))**2)
print(E)
