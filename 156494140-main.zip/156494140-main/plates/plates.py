def main():
    plate = input("Plate: ")
    if is_valid(plate):
        print("Valid")
    else:
        print("Invalid")


def is_valid(s):
    if len(s) < 2 or len(s) > 6:
        return False
    if s.isalnum() or s.isalpha():
        if len(s) > 1 and s.isalpha():
            return True
        ...
    else:
        return False
    for char in s:
        if char.isdigit():
            if char == '0':
                return False
            else:
                break
    if s[0:2].isalpha():
        for i in range(2,len(s)):
            if s[i].isdigit():
                if s[i:].isnumeric():
                    return True
                else:
                    return False
    else:
        return False


if __name__ == '__main__':
    main()
