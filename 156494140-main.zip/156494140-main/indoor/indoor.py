string = input()
print(string.lower())
